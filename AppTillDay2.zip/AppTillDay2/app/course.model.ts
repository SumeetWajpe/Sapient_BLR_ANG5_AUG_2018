export class Course{
  
    constructor(public name:string="Angular",public duration:string="3 Days"){
       
    }
}