export class Product{
    constructor( public name?:string,    
     public price?:number,
     public quantity?:number,
     public rating?:number,
     public ImageUrl?:string    
 ){
 
     }
       
 }