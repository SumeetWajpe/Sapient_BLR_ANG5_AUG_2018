
import {Component, Input} from '@angular/core';
import { Product } from './product.model';

@Component({
    selector:`product`,
   templateUrl:`./app/product.template.html`,
styleUrls:['./app/product.style.css']

})
export class ProductComponent{
      @Input('prodDetails')  prodDetails:Product=new Product();
}