import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'my-app',
  template:`<cart></cart>`
 
  // template: `  

  // <img src="{{imageUrl}}" />
  // <img [src]="imageUrl" />

  // <div *ngFor="let c of courses">
  // <course [details]="c"></course>
  // </div>
  // <course></course>
  // `,
})
export class AppComponent  { 
  imageUrl:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-2E9lbR5dk7ojcF9cORcInuY62WAV9jmgdrRbU-Pv9qwMm0zyNg";
  courses:Course[] = [
    new Course("React","3 Days"),
    new Course("Node","3 Days"),
    new Course("Redux","2 Days")
  ];

 }
